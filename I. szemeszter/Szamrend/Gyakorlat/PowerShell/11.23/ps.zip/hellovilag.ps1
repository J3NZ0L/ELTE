﻿Write-Host "Hello vilag" #nem tudunk tovabb operalni ezzel
Write-Output "hello-vilag!" #objektumot iranyit a kimenetre
