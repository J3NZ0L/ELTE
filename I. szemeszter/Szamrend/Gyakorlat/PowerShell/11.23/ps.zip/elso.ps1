﻿#get-help
#get-command
#get-alias 
#get-content
#New-Item -Path eleresi_utvonal ~uj fajl
#New-Item -ItemType Directory -Path tesztkonyvtar ~ mkdir
#get-ChildItem                                               ~ ls
#Copy-Item -Path teszt.txt -Destination .\tesztkonyvtar      ~ cp
#Set-Location                                                ~ cd
#Rename-Item -Path .\teszt.txt -NewName ujteszt.txt
#Remove-Item -Path .\elso.ps1                                ~ rm
#Remove-Item -Path .\tesztkonyvtar -Recurse                  ~ rm -r

#$x=Get-Content ujteszt.txt
#$x
#$x[2]
#$x.Length
#$x+="uj eleme"