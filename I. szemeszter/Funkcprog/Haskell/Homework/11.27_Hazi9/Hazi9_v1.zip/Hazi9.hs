module Hazi9 where
    data Table = T String
        deriving (Show, Eq)

    to_table :: String -> Table
    to_table s = T s

    change :: Table -> String -> Table
    change T{} s= T s

    data Dummy = Alive Int | Dead
        deriving (Show, Eq)
    
    hit :: Dummy -> Int -> Dummy
    hit Dead _ = Dead
    hit dummy1 damage 
        | getAliveDummyHealth(dummy1)-damage>0 = Alive ((getAliveDummyHealth dummy1)-damage)
        | otherwise = Dead
            where 
                getAliveDummyHealth :: Dummy -> Int
                getAliveDummyHealth (Alive x) = x
                --new_health = getAliveDummyHealth dummy1
    
    multi_hit :: [Dummy] -> Int -> [Dummy]
    multi_hit [] _ = []
    multi_hit (x:xs) damage = [hit x damage] ++ multi_hit xs damage
    
    megahit :: [Dummy] -> Int -> [Dummy]
    megahit [] _ = []
    megahit (x:xs) damage 
        | hit x damage == Dead = [hit x damage] ++ megahit xs (damage-(getAliveDummyHealth x))
        | otherwise = [hit x damage] ++ xs
            where 
                getAliveDummyHealth :: Dummy -> Int
                getAliveDummyHealth (Alive x) = x
