module Nagybeadando where
    --1. feladat
    showState a = show a
    showMage a = show a
    eqMage a b =  a == b
    showUnit a = show a
    showOneVOne a = show a 

    type Name = String
    type Health = Integer
    type Spell = (Integer -> Integer)
    type Army = [Unit]
    type EnemyArmy = Army
    type Amount = Integer

    data State unit = Alive unit | Dead 

    instance (Show u) => Show (State u) where
        --show :: (Show u) => (State u) -> String
        show Dead = "Dead"
        show (Alive unit) = show unit


    data Entity = Golem Health | HaskellElemental Health
        deriving (Show)

    showJustEntityName :: Entity -> String
    showJustEntityName (Golem _) = "Golem"
    showJustEntityName (HaskellElemental _) = "HaskellElemental"

   {- instance Show Entity where
        show :: Entity -> String
        show (Golem h) = "Golem "
        show (HaskellElemental h) = "HaskellElemental "
-}
    data Mage = Master Name Health Spell

    --Masterek
    papi = let 
        tunderpor enemyHP
            | enemyHP < 8 = 0
            | even enemyHP = div (enemyHP * 3) 4
            | otherwise = enemyHP - 3
        in Master "Papi" 126 tunderpor
    java = Master "Java" 100 (\x ->  x - (mod x 9))
    traktor = Master "Traktor" 20 (\x -> div (x + 10) ((mod x 4) + 1))
    jani = Master "Jani" 100 (\x -> x - div x 4)
    skver = Master "Skver" 100 (\x -> div (x+4) 2)
    potionMaster = 
        let plx x
                | x > 85  = x - plx (div x 2)
                | x == 60 = 31
                | x >= 51 = 1 + mod x 30
                | otherwise = x - 7 
        in Master "PotionMaster" 170 plx


    instance Show Mage where
        show (Master name health spell)
            | health < 5 = "Wounded " ++ name
            | otherwise = name

    instance Eq Mage where
        (Master n1 h1 _) == (Master n2 h2 _) = n1 == n2 && h1 == h2

    data Unit = M (State Mage)  | E (State Entity) 

    instance Show Unit where
--        show :: Unit -> String
        show (M s) = tail $ init $ showMage . showState $ s
        show (E s) = show s

    --2. feladat
    {-
    instance Eq (State Unit) where
        (==) :: State Unit -> State Unit -> Bool
        unit1 == unit2 =  showUnit(unit1) == showUnit(unit2)
    -}
    instance Eq Unit where
        M (s1) == M (s2) = show(showUnit(s2)) == show(showUnit(s1))
        E (s1) == E (s2) = show(showUnit(s2)) == show(showUnit(s1))
        _ == _ = False

    formationFix :: Army -> Army  
    formationFix [] = []
    formationFix l@(x:xs) = go l [] []
        where 
            go :: Army -> Army -> Army -> Army
            go [] alive_acc dead_acc = reverse(alive_acc)++reverse(dead_acc)
            go (x:xs) alive_acc dead_acc
                |  showState x == "Dead" = go xs alive_acc (x:dead_acc)
                | otherwise = go xs (x:alive_acc) dead_acc
                
    --3. feladat

    over :: Army -> Bool
    over [] = True
    over (x:xs)= showState x == "Dead" && over xs
        
    --4. feladat
    
    fight :: EnemyArmy -> Army -> Army
    fight [] l = l
    fight l [] = []
    fight ((M (Alive (Master n h s))):xs) l@(y:ys) = [reduceUnitHealth y s] ++ fight xs (reduceArmyHealth ys s)
    fight ((E (Alive (Golem h))):xs) l@(y:ys) = [reduceUnitHealth y (\x -> x-1)] ++ fight xs ys
    fight ((E (Alive (HaskellElemental h))):xs) l@(y:ys) = [reduceUnitHealth y (\x -> x-3)] ++ fight xs ys
    fight ((M (Dead)):xs) (y:ys) =y: fight xs ys 
    fight ((E (Dead)):xs) (y:ys) =y:fight xs ys 

    reduceUnitHealth :: Unit -> (Integer -> Integer) -> Unit
    reduceUnitHealth (M (Alive (Master name health spell))) damagef
        | damagef health <=0 = M $ Dead
        | otherwise = M $ Alive (Master name (damagef health) spell)
    reduceUnitHealth (M (Dead)) _ =  (M (Dead))
    reduceUnitHealth (E (Dead)) _ = (E (Dead))
    reduceUnitHealth (E (Alive (Golem health))) damagef 
        | damagef health <=0 = E $ Dead
        | otherwise = (E (Alive (Golem (damagef health))))
    reduceUnitHealth (E (Alive (HaskellElemental health))) damagef 
        | damagef health <=0 = E $ Dead
        | otherwise = (E (Alive (HaskellElemental (damagef health))))

    reduceArmyHealth :: Army -> (Integer -> Integer) -> Army
    reduceArmyHealth [] _ = []
    reduceArmyHealth (x:xs) f = [reduceUnitHealth x f] ++ reduceArmyHealth xs f

    --5. feladat
    

    