#ifndef SZAMOLOGEP_H
#define SZAMOLOGEP_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define MAX_STRING 100

int menu();

#endif //SZAMOLOGEP_H