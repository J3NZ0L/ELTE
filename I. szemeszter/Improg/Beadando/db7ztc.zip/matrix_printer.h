#ifndef MATRIX_PRINTER_H
#define MATRIX_PRINTER_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void print_matrix(int** Matrix, int N);

#endif