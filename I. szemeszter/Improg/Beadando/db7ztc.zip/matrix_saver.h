#ifndef MATRIX_SAVER_H
#define MATRIX_SAVER_H

#include <stdio.h>
#include <string.h>
#include <stdbool.h>

void save_matrix(int** Matrix,int dimension, int direction,bool rotation);

#endif //MATRIX_SAVER_H