﻿using magas_szintű_mintamegvalósítások;
using System;

namespace ConsoleApp1
{
    internal class Program
    {
        public static int soringadozas(int i, int M, int[,] Matr)
        {
            int[] vec= new int[M];
            for (int j = 0; j<M; j++)
            {
                vec[j] = Matr[i, j];
            }
            int maxind, maxert,minert,minind;
            (maxind,maxert)=Mintak.Max(vec, (a,b) => a>b);
            (minind, minert) = Mintak.Min(vec, (a, b) => a < b);
            return (Math.Abs(minert - maxert));
        }
        public static int soringadozasmin(int N, int M, int[,] Matr)
        {
            int seged;
            int minert=soringadozas(1,M,Matr);
            for (int i=0; i<N; i++)
            {
                seged = soringadozas(i, M, Matr);
                if (minert > seged)
                {
                    minert = seged;
                }
            }
            return (minert);
        }
        
        static void Main(string[] args)
        {
            //Bekeres
            string S=Console.ReadLine();
            int N=int.Parse(S.Split(' ')[0]);
            int M = int.Parse(S.Split(' ')[1]);            
            int[,] elorejelzes=new int[N,M];
            for (int i=0; i<N; i++)
            {
                S = Console.ReadLine();
                for (int j=0; j<M; j++)
                {
                    elorejelzes[i, j] = int.Parse(S.Split(' ')[j]);
                }
            }
            int vsoringadozasmin=soringadozasmin(N,M,elorejelzes);
            bool T(int i)
            {
                return vsoringadozasmin == soringadozas(i, M, elorejelzes);
            }
            //Kivalogatas
            List<int> y=new List<int>();            
            for (int i=0; i<N; i++)
            {
                if (T(i))
                {
                    y.Add(i);
                }
            }
            //Kimenet
            Console.Write(y.Count());
            Console.Write(' ');
            for (int i=0; i<y.Count(); i++)
            {
                Console.Write((y[i]+1) + " ");
            }
           
        }
    }
}